const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  if (req.isAuthenticated()) {
    // If already picked a guild go straight to dashboard, else to picker
    if (req.session.selectedGuildId) {
      return res.redirect('/dashboard');
    }
    return res.redirect('/dashboard/select-guild');
  }
  res.render('login', { title: 'Guess The Song - Login' });
});

module.exports = router;
