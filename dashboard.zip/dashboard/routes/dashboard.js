const express = require('express');
const router = express.Router();
const { ensureAdmin, ensureAuthenticated, getBotGuilds } = require('../config/auth');
const {
  getBotStatus, getBotStats, getBotLeaderboard,
  getBotSongs, getBotLogs, getBotGuildSettings,
  updateBotGuildSettings, getCustomSongs, validateYouTubeUrl,
  addCustomSong, removeCustomSong
} = require('../config/botApi');

// ─── Guild selection ───────────────────────────────────────────────────────

// Show guild picker
router.get('/select-guild', ensureAdmin, (req, res) => {
  res.render('select-guild', {
    title: 'Select Server - Guess The Song',
    user: req.user,
    guilds: req.adminGuilds,
  });
});

// Handle guild selection — only needs basic auth, not ensureAdmin
router.post('/select-guild', ensureAuthenticated, async (req, res) => {
  const { guildId } = req.body;

  // Validate the guild — user must be admin in it
  const ADMINISTRATOR = 0x8;
  const userGuilds = req.user.guilds || [];
  const valid = userGuilds.find(g =>
    g.id === guildId && ((g.permissions & ADMINISTRATOR) === ADMINISTRATOR || g.owner)
  );

  if (!valid) return res.redirect('/dashboard/select-guild');

  req.session.selectedGuildId = guildId;
  res.redirect('/dashboard');
});

// ─── Main dashboard ────────────────────────────────────────────────────────

router.get('/', ensureAdmin, async (req, res) => {
  try {
    const guild = req.selectedGuild;
    const [status, stats, leaderboard, logs] = await Promise.all([
      getBotStatus(),
      getBotStats(),
      getBotLeaderboard(),
      getBotLogs(),
    ]);

    res.render('dashboard', {
      title: 'Dashboard - Guess The Song',
      user: req.user,
      guild,
      status,
      stats,
      leaderboard: leaderboard.slice(0, 5),
      logs: logs.slice(0, 6),
    });
  } catch (err) {
    console.error(err);
    res.render('error', { title: 'Error', message: 'Failed to load dashboard', icon: '❌' });
  }
});

// ─── Songs ─────────────────────────────────────────────────────────────────

router.get('/songs', ensureAdmin, async (req, res) => {
  const [songs, customSongs] = await Promise.all([
    getBotSongs(),
    getCustomSongs(req.selectedGuild.id),
  ]);
  res.render('songs', {
    title: 'Songs - Guess The Song',
    user: req.user,
    guild: req.selectedGuild,
    songs,
    customSongs,
  });
});

// ─── Leaderboard ───────────────────────────────────────────────────────────

router.get('/leaderboard', ensureAdmin, async (req, res) => {
  const leaderboard = await getBotLeaderboard();
  res.render('leaderboard', {
    title: 'Leaderboard - Guess The Song',
    user: req.user,
    guild: req.selectedGuild,
    leaderboard,
  });
});

// ─── Settings ──────────────────────────────────────────────────────────────

router.get('/settings', ensureAdmin, async (req, res) => {
  const guild = req.selectedGuild;
  const settings = await getBotGuildSettings(guild.id);
  res.render('settings', {
    title: 'Settings - Guess The Song',
    user: req.user,
    guild,
    settings,
  });
});

// ─── Logs ──────────────────────────────────────────────────────────────────

router.get('/logs', ensureAdmin, async (req, res) => {
  const logs = await getBotLogs();
  res.render('logs', {
    title: 'Logs - Guess The Song',
    user: req.user,
    guild: req.selectedGuild,
    logs,
  });
});

module.exports = router;
