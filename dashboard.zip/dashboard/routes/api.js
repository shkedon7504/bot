const express = require('express');
const router = express.Router();
const { ensureAdmin } = require('../config/auth');
const {
  getBotStatus, getBotStats, getBotLeaderboard, getBotSongs, getBotLogs,
  getBotGuildSettings, updateBotGuildSettings,
  getCustomSongs, validateYouTubeUrl, addCustomSong, removeCustomSong
} = require('../config/botApi');

// Bot status
router.get('/status', ensureAdmin, async (req, res) => {
  const status = await getBotStatus();
  res.json(status);
});

// Full stats
router.get('/stats', ensureAdmin, async (req, res) => {
  const stats = await getBotStats();
  res.json(stats);
});

// Leaderboard
router.get('/leaderboard', ensureAdmin, async (req, res) => {
  const lb = await getBotLeaderboard();
  res.json(lb);
});

// Songs
router.get('/songs', ensureAdmin, async (req, res) => {
  const songs = await getBotSongs();
  res.json(songs);
});

// Logs
router.get('/logs', ensureAdmin, async (req, res) => {
  const logs = await getBotLogs();
  res.json(logs);
});

// Get guild settings
router.get('/settings/:guildId', ensureAdmin, async (req, res) => {
  const settings = await getBotGuildSettings(req.params.guildId);
  res.json(settings);
});

// Save guild settings
router.post('/settings/:guildId', ensureAdmin, async (req, res) => {
  const { guildId } = req.params;
  const isAdmin = req.adminGuilds.some(g => g.id === guildId);
  if (!isAdmin) return res.status(403).json({ error: 'No permission for this guild' });
  try {
    const result = await updateBotGuildSettings(guildId, req.body);
    res.json(result);
  } catch {
    res.status(503).json({ error: 'Bot offline or unreachable' });
  }
});

// Get custom songs for selected guild
router.get('/custom-songs', ensureAdmin, async (req, res) => {
  const songs = await getCustomSongs(req.selectedGuild.id);
  res.json(songs);
});

// Validate a YouTube URL
router.post('/custom-songs/validate', ensureAdmin, async (req, res) => {
  const { youtubeUrl } = req.body;
  if (!youtubeUrl) return res.status(400).json({ success: false, error: 'No URL provided' });
  try {
    const result = await validateYouTubeUrl(req.selectedGuild.id, youtubeUrl);
    res.json(result);
  } catch {
    res.status(503).json({ success: false, error: 'Bot offline — cannot validate' });
  }
});

// Add a custom song
router.post('/custom-songs', ensureAdmin, async (req, res) => {
  const { track, songName, artistName } = req.body;
  if (!track || !songName || !artistName) {
    return res.status(400).json({ success: false, error: 'Missing fields' });
  }
  try {
    const result = await addCustomSong(req.selectedGuild.id, track, songName, artistName);
    res.json(result);
  } catch {
    res.status(503).json({ success: false, error: 'Bot offline' });
  }
});

// Remove a custom song
router.delete('/custom-songs/:videoId', ensureAdmin, async (req, res) => {
  try {
    const result = await removeCustomSong(req.selectedGuild.id, req.params.videoId);
    res.json(result);
  } catch {
    res.status(503).json({ success: false, error: 'Bot offline' });
  }
});

module.exports = router;
