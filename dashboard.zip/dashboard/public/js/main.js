// Auto-refresh bot status every 30 seconds
if (document.getElementById('statusBadge')) {
  setInterval(async () => {
    try {
      const res = await fetch('/api/status');
      const data = await res.json();
      const badge = document.getElementById('statusBadge');
      const btn = document.getElementById('gameToggleBtn');
      
      if (badge) {
        badge.className = `status-badge ${data.gameRunning ? 'status-online' : 'status-offline'}`;
        badge.innerHTML = `<span class="status-dot"></span> ${data.gameRunning ? 'Game Running' : 'Game Stopped'}`;
      }
    } catch (e) {
      // silent fail
    }
  }, 30000);
}

// Close modal on backdrop click
document.addEventListener('click', (e) => {
  if (e.target.classList.contains('modal')) {
    e.target.classList.remove('show');
  }
});

// Close modal on ESC
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal.show').forEach(m => m.classList.remove('show'));
  }
});
