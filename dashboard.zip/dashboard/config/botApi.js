/**
 * Fetches live data from the bot's internal API (port 3001).
 * Falls back to empty/default values if bot is offline.
 */
const http = require('http');

const BOT_API = `http://127.0.0.1:${process.env.BOT_API_PORT || 3001}`;

function botFetch(path) {
  return new Promise((resolve, reject) => {
    const req = http.get(`${BOT_API}${path}`, { timeout: 3000 }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch { reject(new Error('Invalid JSON')); }
      });
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('Timeout')); });
  });
}

async function getBotStatus() {
  try {
    return await botFetch('/status');
  } catch {
    return { online: false, uptime: 0, gamesRunning: 0, trackPoolSize: 0 };
  }
}

async function getBotStats() {
  try {
    return await botFetch('/stats');
  } catch {
    return {
      totalGamesPlayed: 0, totalCorrectGuesses: 0,
      totalWrongGuesses: 0, totalSkips: 0,
      totalPlayers: 0, topPlayer: '—',
      trackPoolSize: 0, totalSongs: 0,
    };
  }
}

async function getBotLeaderboard() {
  try {
    return await botFetch('/leaderboard');
  } catch {
    return [];
  }
}

async function getBotSongs() {
  try {
    return await botFetch('/songs');
  } catch {
    return [];
  }
}

async function getBotLogs() {
  try {
    return await botFetch('/logs');
  } catch {
    return [];
  }
}

async function getBotGuildSettings(guildId) {
  try {
    return await botFetch(`/settings/${guildId}`);
  } catch {
    return { scoreTable: { 1: 500, 3: 350, 5: 250, 10: 150, 20: 75, 30: 50 }, wrongPenalty: 200, skipPenalty: 200 };
  }
}

async function getCustomSongs(guildId) {
  try { return await botFetch(`/custom-songs/${guildId}`); }
  catch { return []; }
}

async function validateYouTubeUrl(guildId, youtubeUrl) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify({ youtubeUrl });
    const options = {
      hostname: '127.0.0.1',
      port: process.env.BOT_API_PORT || 3001,
      path: `/custom-songs/${guildId}/validate`,
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) },
      timeout: 10000,
    };
    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => { try { resolve(JSON.parse(data)); } catch { reject(new Error('Invalid JSON')); } });
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('Timeout')); });
    req.write(body);
    req.end();
  });
}

async function addCustomSong(guildId, track, songName, artistName) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify({ track, songName, artistName });
    const options = {
      hostname: '127.0.0.1',
      port: process.env.BOT_API_PORT || 3001,
      path: `/custom-songs/${guildId}/add`,
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) },
      timeout: 5000,
    };
    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => { try { resolve(JSON.parse(data)); } catch { reject(new Error('Invalid JSON')); } });
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('Timeout')); });
    req.write(body);
    req.end();
  });
}

async function removeCustomSong(guildId, videoId) {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: '127.0.0.1',
      port: process.env.BOT_API_PORT || 3001,
      path: `/custom-songs/${guildId}/${videoId}`,
      method: 'DELETE',
      timeout: 5000,
    };
    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => { try { resolve(JSON.parse(data)); } catch { reject(new Error('Invalid JSON')); } });
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('Timeout')); });
    req.end();
  });
}
async function updateBotGuildSettings(guildId, newSettings) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify(newSettings);
    const options = {
      hostname: '127.0.0.1',
      port: process.env.BOT_API_PORT || 3001,
      path: `/settings/${guildId}`,
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) },
      timeout: 3000,
    };
    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch { reject(new Error('Invalid JSON')); }
      });
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('Timeout')); });
    req.write(body);
    req.end();
  });
}

module.exports = { getBotStatus, getBotStats, getBotLeaderboard, getBotSongs, getBotLogs, getBotGuildSettings, updateBotGuildSettings, getCustomSongs, validateYouTubeUrl, addCustomSong, removeCustomSong };
