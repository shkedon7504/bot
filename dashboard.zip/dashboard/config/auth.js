const axios = require('axios');

// ADMINISTRATOR permission bit
const ADMINISTRATOR = 0x8;

// Check if user is logged in
const ensureAuthenticated = (req, res, next) => {
  if (req.isAuthenticated()) return next();
  req.flash('error_msg', 'Please login with Discord to access the dashboard');
  res.redirect('/');
};

// Check if user has admin permissions in at least one guild the bot is in.
// Sets req.adminGuilds and req.selectedGuild (from session).
const ensureAdmin = async (req, res, next) => {
  if (!req.isAuthenticated()) {
    req.flash('error_msg', 'Please login with Discord to access the dashboard');
    return res.redirect('/');
  }

  try {
    const botGuilds = await getBotGuilds();
    const userGuilds = req.user.guilds || [];

    // Discord API v10 returns permissions as a string — convert to BigInt for safe bitwise check
    const ADMIN_BIT = BigInt(ADMINISTRATOR);

    const adminGuilds = userGuilds.filter(guild => {
      const perms = BigInt(guild.permissions || 0);
      const hasAdmin = (perms & ADMIN_BIT) === ADMIN_BIT || guild.owner === true;
      if (botGuilds.length > 0) {
        return hasAdmin && botGuilds.some(bg => bg.id === guild.id);
      }
      // Bot offline — show only guilds where user is admin
      return hasAdmin;
    });

    console.log(`[Auth] Bot guilds: ${botGuilds.map(g => g.name).join(', ') || 'none'}`);
    console.log(`[Auth] Filtered adminGuilds: ${adminGuilds.map(g => g.name).join(', ') || 'none'}`);

    if (adminGuilds.length === 0) {
      return res.render('error', {
        title: 'Access Denied',
        message: 'You need Administrator permissions in a server where the bot is present to access this dashboard.',
        icon: '🔒'
      });
    }

    req.adminGuilds = adminGuilds;

    // If no guild selected yet — redirect to guild picker
    if (!req.session.selectedGuildId && !req.path.startsWith('/select-guild')) {
      return res.redirect('/dashboard/select-guild');
    }

    // Validate the stored guild is still valid
    if (req.session.selectedGuildId) {
      const selected = adminGuilds.find(g => g.id === req.session.selectedGuildId);
      if (!selected) {
        req.session.selectedGuildId = null;
        return res.redirect('/dashboard/select-guild');
      }
      req.selectedGuild = selected;
    }

    next();
  } catch (err) {
    console.error('Auth error:', err);
    res.render('error', {
      title: 'Authentication Error',
      message: 'An error occurred while verifying your permissions. Please try again.',
      icon: '❌'
    });
  }
};

// Get guilds the bot is in using Bot token
const getBotGuilds = async () => {
  try {
    const response = await axios.get('https://discord.com/api/v10/users/@me/guilds', {
      headers: { Authorization: `Bot ${process.env.BOT_TOKEN}` }
    });
    return response.data;
  } catch (err) {
    console.error('Failed to fetch bot guilds:', err.message);
    return [];
  }
};

module.exports = { ensureAuthenticated, ensureAdmin, getBotGuilds };
