# 🎵 Guess The Song - Bot Dashboard

דאשבורד לניהול הבוט של דיסקורד "Guess The Song".

## הגדרה

### 1. התקנת חבילות
```bash
cd dashboard
npm install
```

### 2. יצירת קובץ .env
העתק את `.env.example` לקובץ חדש בשם `.env`:
```bash
cp .env.example .env
```

ומלא את הפרטים:

```env
DISCORD_CLIENT_ID=your_client_id
DISCORD_CLIENT_SECRET=your_client_secret
DISCORD_CALLBACK_URL=http://localhost:3000/auth/discord/callback
BOT_TOKEN=your_bot_token
SESSION_SECRET=any_random_string_here
PORT=3000
```

### 3. הגדרת Discord OAuth2

1. לך ל-[Discord Developer Portal](https://discord.com/developers/applications)
2. בחר את האפליקציה שלך (או צור חדשה)
3. לך ל-**OAuth2 → Redirects**
4. הוסף: `http://localhost:3000/auth/discord/callback`
5. העתק את **Client ID** ו-**Client Secret** לקובץ `.env`

### 4. הפעלה
```bash
npm start
# או בפיתוח:
npm run dev
```

פתח: http://localhost:3000

## גישה לדאשבורד

רק משתמשים שיש להם **Administrator** בשרת שהבוט נמצא בו יוכלו לגשת.

## עמודים

| עמוד | כתובת | תיאור |
|------|--------|-------|
| Overview | `/dashboard` | סטטיסטיקות כלליות, גרפים, לוחות |
| Songs | `/dashboard/songs` | ניהול רשימת השירים |
| Leaderboard | `/dashboard/leaderboard` | טבלת ניקוד שחקנים |
| Logs | `/dashboard/logs` | לוגים של הבוט |
| Settings | `/dashboard/settings` | הגדרות המשחק |

## טכנולוגיות

- **Backend**: Node.js + Express
- **Auth**: Discord OAuth2 (passport-discord)
- **Views**: EJS templates
- **Charts**: Chart.js
- **Icons**: Font Awesome
