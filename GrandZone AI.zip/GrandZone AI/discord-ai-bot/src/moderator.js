/**
 * moderator.js
 * Local keyword/regex content filter (no external API needed).
 * Free, instant, works without any paid service.
 */

// ── Blocked patterns ──────────────────────────────────────────────────────────
const RULES = [
  // Self-harm (highest priority)
  { pattern: /\bאני\s+רוצה\s+למות\b|\bלהתאבד\b/i, type: 'selfharm' },

  // Threats / violence
  { pattern: /\bאהרוג\b|\bאפצח\b|\bלהרוג\b|\bi (will |'ll )?kill you\b|\bdie\s+bitch\b/i, type: 'threat' },

  // Spam
  { pattern: /(.)\1{9,}/, type: 'spam' },                        // same char x10
  { pattern: /(https?:\/\/[^\s]+\s*){5,}/i, type: 'spam' },      // 5+ links

  // Hebrew profanity / slurs
  { pattern: /\bזין\b|\bכוס\b|\bשרמוטה\b|\bמזדיין\b|\bבן זונה\b|\bלך תזדיין\b|\bדפוק\b|\bמנטק\b/i, type: 'profanity' },

  // English profanity / slurs
  { pattern: /\bf+u+c+k+\b|\bsh+i+t+\b|\bb+i+t+c+h+\b|\bn+i+g+g+[ae]+r+\b|\bc+u+n+t+\b|\bass+h+o+l+e+\b/i, type: 'profanity' },
];

const REASONS = {
  selfharm:  '⚠️ זיהינו תוכן הנוגע לפגיעה עצמית. אנחנו כאן בשבילך – דבר עם מישהו שאתה סומך עליו.',
  threat:    '⚠️ הודעתך הכילה תוכן מאיים ולכן הוסרה.',
  spam:      '⚠️ הודעתך זוהתה כספאם ולכן הוסרה.',
  profanity: '⚠️ הודעתך הכילה שפה פוגענית ולכן הוסרה.',
};

/**
 * Check a message against all local rules.
 * @param {string} text
 * @returns {{ blocked: boolean, reason?: string }}
 */
function filterMessage(text) {
  for (const rule of RULES) {
    if (rule.pattern.test(text)) {
      return { blocked: true, reason: REASONS[rule.type] };
    }
  }
  return { blocked: false };
}

/**
 * Send a private warning DM to the user.
 * Gracefully handles cases where the user has DMs disabled.
 * @param {import('discord.js').User} user
 * @param {string} reason
 */
async function sendWarning(user, reason) {
  try {
    await user.send(`${reason}\n\nאם לדעתך מדובר בטעות, פנה למנהל השרת.`);
  } catch (err) {
    console.warn(`⚠️  Could not DM user ${user.tag}:`, err.message);
  }
}

module.exports = { filterMessage, sendWarning };
