require('dotenv').config();
const { Client, GatewayIntentBits, Events } = require('discord.js');
const { getAIResponse } = require('./aiHandler');
const { filterMessage, sendWarning } = require('./moderator');

// ── Validate required env vars ────────────────────────────────────────────────
const required = ['DISCORD_TOKEN', 'GROQ_API_KEY', 'TARGET_CHANNEL_ID'];
for (const key of required) {
  if (!process.env[key]) {
    console.error(`❌  Missing required environment variable: ${key}`);
    process.exit(1);
  }
}

const TARGET_CHANNEL_ID = process.env.TARGET_CHANNEL_ID;

// ── Create Discord client ─────────────────────────────────────────────────────
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

// ── Ready ─────────────────────────────────────────────────────────────────────
client.once(Events.ClientReady, (c) => {
  console.log(`✅  Logged in as ${c.user.tag}`);
  console.log(`📡  Listening on channel ID: ${TARGET_CHANNEL_ID}`);
});

// ── Message handler ───────────────────────────────────────────────────────────
client.on(Events.MessageCreate, async (message) => {
  // Ignore bots (including itself)
  if (message.author.bot) return;

  // Only act in the target channel
  if (message.channel.id !== TARGET_CHANNEL_ID) return;

  const content = message.content.trim();
  if (!content) return;

  // ── 1. Content moderation (local filter) ─────────────────────────────────
  const modResult = filterMessage(content);

  if (modResult.blocked) {
    console.log(`🚫  Blocked message from ${message.author.tag}: "${content}"`);
    try {
      await message.delete();
    } catch (err) {
      console.warn('⚠️  Could not delete message (missing permissions?):', err.message);
    }
    await sendWarning(message.author, modResult.reason);
    return;
  }

  // ── 2. Show typing indicator ──────────────────────────────────────────────
  await message.channel.sendTyping();

  // ── 3. Get AI response ────────────────────────────────────────────────────
  try {
    const reply = await getAIResponse(content, message.author.username);

    // Discord messages are limited to 2000 chars – split if needed
    const chunks = splitMessage(reply);
    for (const chunk of chunks) {
      await message.reply(chunk);
    }
  } catch (err) {
    console.error('❌  AI response error:', err.message);
    await message.reply('⚠️ אירעה שגיאה בעת קבלת תגובה. נסה שוב מאוחר יותר.');
  }
});

// ── Helpers ───────────────────────────────────────────────────────────────────
/**
 * Split a long string into ≤2000-char chunks, breaking on newlines where possible.
 */
function splitMessage(text, maxLength = 1900) {
  if (text.length <= maxLength) return [text];

  const chunks = [];
  while (text.length > 0) {
    let chunk = text.slice(0, maxLength);
    const lastNewline = chunk.lastIndexOf('\n');
    if (lastNewline > maxLength / 2) chunk = chunk.slice(0, lastNewline);
    chunks.push(chunk);
    text = text.slice(chunk.length);
  }
  return chunks;
}

// ── Login ─────────────────────────────────────────────────────────────────────
client.login(process.env.DISCORD_TOKEN);
