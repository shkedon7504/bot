const Groq = require('groq-sdk');

const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });

const SYSTEM_PROMPT =
  process.env.BOT_SYSTEM_PROMPT ||
  'אתה עוזר AI ידידותי בשרת Discord. ענה בעברית אלא אם כן הפנייה אליך היא בשפה אחרת. היה מנומס, קצר וברור.';

// Per-user conversation history: Map<username, Array<{role, content}>>
const conversationHistory = new Map();
const MAX_HISTORY = 10;

/**
 * Get an AI response using Groq (free tier).
 * @param {string} userMessage
 * @param {string} username
 * @returns {Promise<string>}
 */
async function getAIResponse(userMessage, username) {
  if (!conversationHistory.has(username)) {
    conversationHistory.set(username, []);
  }
  const history = conversationHistory.get(username);

  // Add new user message
  history.push({ role: 'user', content: userMessage });

  // Trim to max history
  while (history.length > MAX_HISTORY * 2) {
    history.splice(0, 2);
  }

  const messages = [
    { role: 'system', content: `${SYSTEM_PROMPT}\nאתה משוחח עם המשתמש: ${username}` },
    ...history,
  ];

  const completion = await groq.chat.completions.create({
    model: process.env.GROQ_MODEL || 'openai/gpt-oss-20b',
    messages,
    max_tokens: parseInt(process.env.MAX_TOKENS, 10) || 500,
    temperature: 0.7,
  });

  const reply = completion.choices[0]?.message?.content?.trim() || 'לא הצלחתי לייצר תשובה.';

  // Save assistant reply to history
  history.push({ role: 'assistant', content: reply });

  return reply;
}

function clearHistory(username) {
  conversationHistory.delete(username);
}

module.exports = { getAIResponse, clearHistory };
