@echo off
title Discord AI Bot
cd /d "%~dp0"

echo.
echo  ================================
echo    Discord AI Bot - Starting...
echo  ================================
echo.

:: Install dependencies if node_modules doesn't exist
if not exist "node_modules" (
    echo  [*] Installing dependencies...
    npm install
    echo.
)

echo  [*] Starting bot...
echo.
node src/index.js

echo.
echo  [!] Bot stopped. Press any key to exit.
pause >nul
