# 🤖 Discord AI Bot

בוט Discord חכם שעונה על הודעות בחדר ספציפי באמצעות OpenAI, ומסנן תוכן לא הולם בשתי שכבות הגנה.

---

## ✨ יכולות

| יכולת | פרטים |
|-------|--------|
| 🧠 AI שיחה | עונה על הודעות ב-ChatGPT (gpt-4o-mini כברירת מחדל) |
| 💬 זיכרון שיחה | שומר הקשר של עד 10 הודעות לכל משתמש |
| 🚫 סינון מקומי | חסימת גידופים, איומים וספאם במיידי (ללא API) |
| 🤖 סינון AI | שכבת OpenAI Moderation API לדיוק גבוה |
| 📩 התראות | שולח DM פרטי למשתמש שהודעתו נחסמה |
| 🗑️ מחיקה אוטומטית | מוחק הודעות פוגעניות מהחדר |
| 📍 חדר ייעודי | הבוט פועל רק בחדר שהגדרת |

---

## 📁 מבנה הפרויקט

```
discord-ai-bot/
├── src/
│   ├── index.js        # כניסה ראשית – Discord client והודעות
│   ├── aiHandler.js    # תקשורת עם OpenAI Chat API
│   └── moderator.js    # סינון תוכן (מקומי + OpenAI Moderation)
├── .env.example        # תבנית משתני סביבה
├── .gitignore
├── package.json
└── README.md
```

---

## 🚀 התקנה והפעלה

### דרישות מקדימות
- [Node.js](https://nodejs.org/) גרסה 18 ומעלה
- חשבון [Discord Developer](https://discord.com/developers/applications)
- מפתח API של [OpenAI](https://platform.openai.com/api-keys)

---

### שלב 1 – צור בוט ב-Discord

1. כנס ל-[Discord Developer Portal](https://discord.com/developers/applications)
2. לחץ **New Application** → תן שם
3. עבור ל-**Bot** → לחץ **Add Bot**
4. תחת **Privileged Gateway Intents** הפעל:
   - ✅ `MESSAGE CONTENT INTENT`
   - ✅ `SERVER MEMBERS INTENT`
5. לחץ **Reset Token** → העתק את הטוקן
6. עבור ל-**OAuth2 → URL Generator**:
   - Scopes: `bot`
   - Bot Permissions: `Send Messages`, `Read Messages/View Channels`, `Manage Messages`, `Read Message History`
7. פתח את ה-URL שנוצר והוסף את הבוט לשרת שלך

---

### שלב 2 – קבל את מזהה החדר

1. ב-Discord: **Settings → Advanced → הפעל Developer Mode**
2. לחץ ימני על החדר הרצוי → **Copy Channel ID**

---

### שלב 3 – הגדר את הפרויקט

```bash
# שכפל / פתח את תיקיית הפרויקט
cd discord-ai-bot

# התקן תלויות
npm install

# צור קובץ .env מהתבנית
copy .env.example .env
```

פתח את קובץ `.env` ומלא את הערכים:

```env
DISCORD_TOKEN=הטוקן_שלך_מהדיסקורד
OPENAI_API_KEY=המפתח_שלך_מ_openai
TARGET_CHANNEL_ID=מזהה_החדר_שבחרת
OPENAI_MODEL=gpt-4o-mini
BOT_SYSTEM_PROMPT=אתה עוזר AI ידידותי בשרת Discord. ענה בעברית.
MAX_TOKENS=500
```

---

### שלב 4 – הפעל

```bash
# הפעלה רגילה
npm start

# הפעלה עם auto-restart בעת שינוי קוד (פיתוח)
npm run dev
```

תראה בטרמינל:
```
✅  Logged in as YourBot#1234
📡  Listening on channel ID: 123456789012345678
```

---

## ⚙️ התאמה אישית

### שינוי אישיות הבוט
ערוך `BOT_SYSTEM_PROMPT` ב-`.env`:
```env
BOT_SYSTEM_PROMPT=אתה בוט שירות לקוחות של חברת GrandZone. ענה בנימוס ובקצרה.
```

### הוספת מילים חסומות
פתח `src/moderator.js` והוסף ל-`BLOCKED_PATTERNS`:
```js
/\bמילה_חסומה\b/i,
```

### שינוי מודל AI
```env
OPENAI_MODEL=gpt-4o        # איכות גבוהה יותר, יקר יותר
OPENAI_MODEL=gpt-3.5-turbo # מהיר וזול
```

### הוספת עוד חדרים
ב-`src/index.js` שנה את בדיקת החדר:
```js
const ALLOWED_CHANNELS = process.env.TARGET_CHANNEL_ID.split(',');
if (!ALLOWED_CHANNELS.includes(message.channel.id)) return;
```
ואז ב-`.env`:
```env
TARGET_CHANNEL_ID=111111111111,222222222222
```

---

## 🛡️ שכבות הסינון

```
הודעה נכנסת
     │
     ▼
┌─────────────────────────┐
│  Layer 1: Local Filter  │  ← מיידי, ללא עלות
│  regex + blocklist       │    גידופים, איומים, ספאם
└───────────┬─────────────┘
            │ עבר ✅
            ▼
┌─────────────────────────┐
│  Layer 2: OpenAI        │  ← מדויק, async
│  Moderation API         │    hate, violence, sexual...
└───────────┬─────────────┘
            │ עבר ✅
            ▼
     שאילתת AI → תשובה
```

---

## 🔐 הרשאות נדרשות בדיסקורד

| הרשאה | סיבה |
|--------|------|
| `Read Messages` | לקרוא הודעות בחדר |
| `Send Messages` | לשלוח תשובות |
| `Manage Messages` | למחוק הודעות פוגעניות |
| `Read Message History` | הקשר שיחה |

---

## 📝 רישיון

MIT – שימוש חופשי לכל מטרה.
